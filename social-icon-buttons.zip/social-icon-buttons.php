<?php
/*
Plugin Name: Social Icon Buttons Plugin
Description: Social Icon Buttons multitek.no
Version: 1.1
Author: Multitek
Author URI: http://multitek.no
*/

/*
=======
Filters
=======
*/

function add_social_icons( $content ) {
    // Don't run the function unless we're on a page it applies to
	if ( ! is_singular() )
		return $content;

	if (!is_home() && !is_front_page() && is_page() && is_single()) {

		$urlCurrentPage = get_permalink($post->ID);
		$strPageTitle = get_the_title($post->ID);
		$shareText = urlencode(html_entity_decode($strPageTitle . ' - Multitek', ENT_COMPAT, 'UTF-8'));
		$emailTitle = str_replace('&', '%26', $strPageTitle);

		if(has_post_thumbnail())
        {
            // get the featured image
            $urlPostThumb = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
            $urlPostThumb = $urlPostThumb[0];
        }
        // no featured image set
        else
        {
            // use the pinterest default
            $urlPostThumb = 'https://cdn.multitek.no/img/multitek-logo/logo_gjennomsiktig_facebook.png';
        }

		$share_buttons = '
		<div class="social-icons">
			<a href="http://www.facebook.com/sharer.php?u=' . $urlCurrentPage . '" class="facebook" target="_blank"><i class="social fa fa-facebook" aria-hidden="true"></i></a>
			<a href="http://twitter.com/share?url=' . $urlCurrentPage . '&text=' . $shareText . '" class="twitter" target="_blank"><i class="social fa fa-twitter" aria-hidden="true"></i></a>
			<a href="https://plus.google.com/share?url=' . $urlCurrentPage . '" class="google-plus" target="_blank"><i class="social fa fa-google-plus" aria-hidden="true"></i></a>
			<a href="http://pinterest.com/pin/create/bookmarklet/?is_video=false&url=' . $urlCurrentPage . '&media=' . $urlPostThumb . '&description=' . $strPageTitle . '" class="pinterest" target="_blank"><i class="social fa fa-pinterest-p" aria-hidden="true"></i></a>
			<a href="http://reddit.com/submit?url=' . $urlCurrentPage  . '&amp;title=' . $strPageTitle . '" class="reddit" target="_blank"><i class="social fa fa-reddit-alien" aria-hidden="true"></i></a>
			<a href="mailto:?subject=' . $emailTitle . '&amp;body=' . $arrSettings['ssba_email_message'] . '%20' . $urlCurrentPage  . '" class="email" target="_blank"><i class="social fa fa-envelope" aria-hidden="true"></i></a>
			<a href="#" onclick="window.print()" class="print" target="_blank"><i class="social fa fa-print" aria-hidden="true"></i></a>
		</div>
		';
		$returnContent = $share_buttons . $content . $share_buttons;

    	return $returnContent;
	}
	return $content;
}
add_filter( 'the_content', 'add_social_icons' );

/*
=======
Actions
=======
*/

function add_icon_stylesheet() {
    wp_enqueue_style( 'social-icon-buttons', get_template_directory_uri() . '/social-icons.css' );
}
add_action( 'wp_enqueue_scripts', 'add_icon_stylesheet' );

?>